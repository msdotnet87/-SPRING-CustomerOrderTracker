package com.msi.panel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PanelWebletApplicationTests {

	@Test
	void contextLoads() {
	}

}
