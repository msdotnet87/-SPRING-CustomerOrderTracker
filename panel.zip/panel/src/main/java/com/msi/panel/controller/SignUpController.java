package com.msi.panel.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SignUpController {



    @GetMapping("/api/test")
    public String apiTest(){
        return "Hello Api";
    }

}
