package com.msi.panel.components;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class DaoAuthProvider implements AuthenticationProvider {

    UserDetailsService userDetailsService;

    @Autowired
    public DaoAuthProvider(UserDetailsService userDetailsService){
        this.userDetailsService = userDetailsService;
    }


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
     String username = authentication.getName();
     Object credentials = authentication.getCredentials();
        Assert.notNull(username, "Username cannot be null");
        Assert.notNull(credentials, "Password cannot be null");
     if (!(credentials instanceof String)){
       return null;
     }
     String password = credentials.toString();
    UserDetails userDetails = userDetailsService.loadUserByUsername(username);
    boolean PassMatch = userDetails.getPassword().equals(password);
    if (!PassMatch){
        throw new BadCredentialsException("Incorrect password provided");
    }
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=
            new UsernamePasswordAuthenticationToken(username, password, userDetails.getAuthorities());

    return usernamePasswordAuthenticationToken;

    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
}
