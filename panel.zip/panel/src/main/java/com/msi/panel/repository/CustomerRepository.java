package com.msi.panel.repository;

import com.msi.panel.entity.Customer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface CustomerRepository extends CrudRepository<Customer, Long> {

    @Query("SELECT u FROM Customer u")
    public List<Customer> showAllCustomer();

    @Query("SELECT u FROM Customer u WHERE u.nip=:nip")
    public List<Customer> showCustomerbynip(@Param("nip")int nip);

    @Query("SELECT u FROM Customer u WHERE u.nazwaFirmy=:nazwa")
    public List<Customer> showCustomerbyname(@Param("nazwa")String nazwa);

    //public List<Customer> findByQuantityBetween(int minquantity, int maxquantity);
    //findByQuantityGreaterThenEqualOrderBy


}
