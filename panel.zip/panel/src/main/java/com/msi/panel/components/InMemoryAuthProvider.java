package com.msi.panel.components;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;



public class InMemoryAuthProvider implements AuthenticationProvider {

    private static final String username_null_ex= "Cannot use empty username";
    private static final String credentials_not_null_ex= "Cannot use empty credentials";
    /*************************
     *
      */
    UserDetailsService userDetailsService;

    @Autowired
    public InMemoryAuthProvider(UserDetailsService userDetailsService){
       this.userDetailsService = userDetailsService;
   }
   /*
   *************
    */
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username = authentication.getName();
        Object credentials = authentication.getCredentials();
        Assert.notNull(username, username_null_ex);
        Assert.notNull(credentials, credentials_not_null_ex);
            if(!(credentials instanceof String)){
                return null;
            }
        String password = credentials.toString();
        UserDetails userDetails = userDetailsService.loadUserByUsername(username);

        if (!password.equals(userDetails.getPassword())){
            throw new BadCredentialsException("Password is incorect");
        }

        UsernamePasswordAuthenticationToken upat = new UsernamePasswordAuthenticationToken(username,
                password,
                userDetails.getAuthorities());
        return upat;
    }

    @Override
    public boolean supports(Class<?> authentication) {
       return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
}
