package com.msi.panel.service;


import com.msi.panel.entity.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class InMemoryUserDetailServiceImpl implements UserDetailsService {

    private static final String USER_NOT_EXIST = "User with username %s does not exist";
    private List<UserDetails> users;

    public InMemoryUserDetailServiceImpl(){
        users = new ArrayList<UserDetails>();
        users.add(new User("user1", "user", Arrays.asList("USER")));
        users.add(new User("user2", "user", Arrays.asList("USER")));
        users.add(new User("user3", "user", Arrays.asList("USER", "ADMIN")));
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Assert.notNull(username, "Username cannot be null");
        Optional<UserDetails> optuser = users.stream().filter(u -> username
                .equals(u
                .getUsername()))
                .findFirst();
        if(!optuser.isPresent()){
            throw new UsernameNotFoundException(String.format(USER_NOT_EXIST, username));
        }
        return optuser.get();
    }
}
