package com.msi.panel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanelWebletApplication {

	public static void main(String[] args) {
		SpringApplication.run(PanelWebletApplication.class, args);
	}

}
